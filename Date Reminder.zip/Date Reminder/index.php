<html>
<head>
    <title>Exercise Reminder Management System</title>
	 <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
</head>
<body>
      <p align="right"  ><a href="login.php">Admin Login</a></p>
	  <h1 align="center">Welcome to Exercise Reminder Management System</h1>
