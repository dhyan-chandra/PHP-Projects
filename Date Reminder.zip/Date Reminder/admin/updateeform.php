 <?php


              session_start();
			  
			  if($_SESSION['uid'])
			  {
				 echo "";
			  }
			  else
			  {
				  header('location:  ../login.php');
			  }
			  
			  
	?>	

<?php
      
	  include('header.php');
	  include('../dbcon.php');
	
	  $sid = $_GET['sid'];
	  
	  $qry = "SELECT * FROM `reminder` WHERE `id`='$sid'";
	  
	  $run = mysqli_query($con,$qry);
	  
	  $data = mysqli_fetch_assoc($run);
	  
	  

?>
<hr/><br/>
<table class="tab" align="center">
      <form method="post" action="updatedata.php" enctype="multipart/form-data">
	  <tr>
	       <td>Date</td>
		   <td><input type="text" name="date" value=<?php  echo $data['date'];   ?> required /></td>
	  </tr>
	   <tr>
	       <td>Subject</td>
		   <td><input type="text" name="subject" value=<?php  echo $data['subject'];   ?> required /></td>
	  </tr>
	   <tr>
	       <td>Description</td>
		   <td><input type="text" name="description" value=<?php  echo $data['description'];   ?> required /></td>
	  </tr>
	   <tr>
	       <td>Email</td>
		   <td><input type="email" name="email" value=<?php  echo $data['email'];   ?> required /></td>
	  </tr>
	   <tr>
	       <td>Contact</td>
		   <td><input type="text" name="contact" value=<?php  echo $data['contact'];   ?> required /></td>
	  </tr>
	   <tr>
	       <td>sms</td>
		   <td><input type="text" name="sms" value=<?php  echo $data['sms'];   ?> required /></td>
	  </tr>
	   <tr>
	       <td>Recurrence for Next</td>
		   <td><input type="text" name="recurrence" value=<?php  echo $data['recurrence'];   ?> required /></td>
	  </tr>
	  
	  
	   <tr>
	       <td><br /></td>
		   <td><br/></td>
	   </tr>
	   <tr>
	       <br />
		   <td colspan="2" align="center">
		   <input type="hidden" name="sid" value="<?php echo $data['id']; ?>" />
		   <input type="submit" name="submit" value="Submit" /></td>
	  </tr>
    </form>
</table>