
    <?php


              session_start();
			  
			  if($_SESSION['uid'])
			  {
				 echo "";
			  }
			  else
			  {
				 header('location:../login.php');
			  }
			  
			  
	?>		
	
	<?php 
	
	   include('header.php');
	   
	   ?>  
	   
	   <br />
	   <hr/>
	 
	   <div class="adminp">
	        <H3><a href="addtimetable.php">Set Reminder Information</a></h3>
			<hr style="width:440px"/>
			 <h3><a href="updatetimetable.php">Modify Reminder Information</a></h3>
			 <hr style="width:440px"/>
			 <h3><a href="deletetimetable.php">Delete Reminder Information</a></h3>
			 <hr style="width:440px"/>
			 <H3><a href="disable.php">Disable Reminder Information</a></h3>
			<hr style="width:440px"/>
			 <h3><a href="enable.php">Enable Reminder Information</a></h3>
			 <hr style="width:440px"/>
			 <h3><a href="view.php">View Reminder Information</a></h3>
			 <hr style="width:440px"/>
	   </div>
	   
	   </body>
	   </html>