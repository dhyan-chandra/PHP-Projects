  <?php


              session_start();
			  
			  if($_SESSION['uid'])
			  {
				 echo "";
			  }
			  else
			  {
				  header('location:  ../login.php');
			  }
			  
			  
	?>	

<?php
      
	  include('header.php');

?>

<hr/><br/>
<table class="tab" align="center">
 <h3 align="center" style="color:blue;" >Delete Reminder Information</h3>
 <br>
 <form method="post" action="deletetimetable.php" enctype="multipart/form-data">
	 
	   <tr>
	       <td>Select Date</td>
		   <td><input type="date" data-date-inline-picker="true" name="date" required /></td>
	  </tr>
	    <tr>
	       <td>Select Subject</td>
		   <td> <select name="subject"  required >
				 <option>---Select Subject--</option>
				 <option value="Android">Android</option>
				 <option value="PHP">PHP</option>
				 <option value="Java">Java</option>
				 <option value="JavaScript">JavaScript</option>
				 <option value="Maths">Maths</option>
				 
                 </select></td>
	  </tr>
	  
	    <tr>
	       <td>Description</td>
		   <td><input type="text" name="description" /></td>
	  </tr>
     
	   <tr>
			
		   <td colspan="2" align="center"><input style="background-color:green; color:white" type="submit" name="submit" value="Confirm" /></td>
	  </tr>
</form>
</table>


<?php

   if(isset($_POST['submit']))
   {
       include('../dbcon.php');
	   
	   $date = $_POST['date'];
	   $subject = $_POST['subject'];
	   $description = $_POST['description'];
	   
	   
	   $sql = "SELECT * FROM `reminder` WHERE `date` = '$date' OR `subject` = '$subject' OR `description` = '$description'";
	   
	   $run = mysqli_query($con,$sql);
	   
	   if(mysqli_num_rows($run)<1)
	   {
	      echo "<tr><td>No record found</td></tr>";
	   }
	   else
	   {
	       $count=0;
		   while($data = mysqli_fetch_assoc($run))
		   {
		     $count++;
			 ?>
			 <table align="center" width="80%" border="1px">
			 
			 <tr>
			        <td align="center"><b>Record No.</b></td>
					 <td align="center"><b>Date</b></td>
					  <td align="center"><b>Subject</b></td>
					   <td align="center"><b>Description</b></td>
					    <td align="center"><b>Email</b></td>
						 <td align="center"><b>Contact</b></td>
						  <td align="center"><b>SMS</b></td>
						   <td align="center"><b>Recurrence</b></td>
						   <td align="center"><b>Operation</b></td>
						    
			 </tr>
			 
			 <br>
			 
			 <tr>
			     <td align="center"><?php echo $count; ?></td>
					 
	             <td align="center"><?php echo $data['date']; ?></td>
				 <td align="center"><?php echo $data['subject']; ?></td>
				 <td align="center"><?php echo $data['description']; ?></td>
				 <td align="center"><?php echo $data['email']; ?></td>
				 <td align="center"><?php echo $data['contact']; ?></td>
				 <td align="center"><?php echo $data['sms']; ?></td>
				 <td align="center"><?php echo $data['recurrence']; ?></td>
				 
				 
				 <td align="center"><a href="deleteform.php?sid=<?php echo $data['id']; ?>">DELETE</a></td>
			 </tr>
			 </table>
			 <?php
		   }
	   }
   
   }
?>
 