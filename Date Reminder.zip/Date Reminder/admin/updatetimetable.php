  <?php


              session_start();
			  
			  if($_SESSION['uid'])
			  {
				 echo "";
			  }
			  else
			  {
				  header('location:  ../login.php');
			  }
			  
			  
	?>	

<?php
      
	  include('header.php');

?>
<hr/><br/>

<table class="tab" align="center">
       
    <h3 align="center" style="color:blue;">Modify Reminder Information</h3>
      <form method="post" action="updatetimetable.php" enctype="multipart/form-data">
	   <tr>
	       <td>Select Date</td>
		   <td><input type="date" data-date-inline-picker="true" name="date" required /></td>
	  </tr>
	  <tr>
	     <td>Select Subject</td>
	     <td>
	        
 
				 <select name="subject" >
				 <option>---Select Subject--</option>
				 <option value="Android">Android</option>
				 <option value="PHP">PHP</option>
				 <option value="Java">Java</option>
				 <option value="JavaScript">JavaScript</option>
				 <option value="Maths">Maths</option>
				 
                 </select>
	    </td>
	</tr>
	<!--<tr>
	       <td>Add Description</td>
		   <td><textarea type="textarea" name="description" form="usrform"  required >Enter text here...</textarea></td>
	  </tr>
	  <tr>
	       <td>Email Address</td>
		   <td><input type="email" name="email" id="email" pattern=".+@gmail.com" size="30"  required></td>
	  </tr>
	   <tr>
	       <td>Contact No.</td>
		   <td><input type="text" name="contact" required /></td>
	  </tr> <tr>
	       <td>SMS No.</td>
		   <td><input type="text" name="sms" /></td>
	  </tr>
	   <tr>
	       <td>Recurrence for next</td>
		   <td><input type="checkbox" name="recurrence" value="7days"><label>7days</label>
		       <input type="checkbox" name="recurrence" value="5days"><label>5days</label>
			   <input type="checkbox" name="recurrence" value="3days"><label>3days</label>
			   <input type="checkbox" name="recurrence" value="2days"><label>2days</label>
		   
		   </td>
	  </tr>    -->
	   <tr>
	       <td><br /></td>
		   <td><br/></td>
	   </tr>
	   <tr>
	       <br />
		   <td colspan="2" align="center"><input type="submit" name="submit" value="Confirm" /></td>
	  </tr>  
    </form>
</table>

<br>


<!--
<table class="tab" align="center">

 <form method="post" action="updatetimetable.php" enctype="multipart/form-data">
	 
	   <tr>
	       <td>Enter College</td>
		   <td><input type="text" name="college" required /></td>
	  </tr>
	    <tr>
	       <td> Enter Course</td>
		   <td><input type="text" name="course" required /></td>
	  </tr>
	  <tr>
	       <td>Enter Branch</td>
		   <td><input type="text" name="branch" required /></td>
	  </tr>
	    <tr>
	       <td> Enter Session Year</td>
		   <td><input type="number" name="sessionyear" required /></td>
	  </tr>
	   <tr>
	       <br />
		   <td colspan="2" align="center"><input type="submit" name="submit" value="Submit" /></td>
	  </tr>
</form>
</table>

-->
<?php

   if(isset($_POST['submit']))
   {
       include('../dbcon.php');
	   
	   $date = $_POST['date'];
		 $subject = $_POST['subject'];
		/* $description = $_POST['description'];
		 $email = $_POST['email'];
		 $contact = $_POST['contact'];
		 $sms = $_POST['sms'];
		 $recurrence = $_POST['recurrence'];  */
		 
	   
	   $sql = "SELECT * FROM `reminder` WHERE `date` = '$date' OR `subject` = '$subject' ";
	   
	   $run = mysqli_query($con,$sql);
	   
	   if(mysqli_num_rows($run)<1)
	   {
	      echo "<tr><td>No record found</td></tr>";
	   }
	   else
	   {
	       $count=0;
		   while($data = mysqli_fetch_assoc($run))
		   {
		     $count++;
			 ?>
			 <table align="center" width="80%" border="1px">
			 <tr>
			     <td align="center"><?php echo $count; ?></td>
				 <td align="center"><?php echo $data['date']; ?></td>
				 <td align="center"><?php echo $data['subject']; ?></td>
				 <td align="center"><?php echo $data['description']; ?></td>
				 <td align="center"><?php echo $data['email']; ?></td>
				 <td align="center"><?php echo $data['contact']; ?></td>
				 <td align="center"><?php echo $data['sms']; ?></td>
				 <td align="center"><?php echo $data['recurrence']; ?></td>
				
				 <td align="center"><a href="updateeform.php?sid=<?php echo $data['id']; ?>">Edit</a></td>
			 </tr>
			 </table>
			 <?php
		   }
	   }
   
   }
?>
  