<?php 

 include('../dbcon.php');
		
		
	     $date = $_POST['date'];
		 $subject = $_POST['subject'];
		 $description = $_POST['description'];
		 $email = $_POST['email'];
		 $contact = $_POST['contact'];
		 $sms = $_POST['sms'];
		 $recurrence = $_POST['recurrence'];
		
		 
		 $id = $_POST['sid'];
		
		 
		 
		
	 
	   $qry = "UPDATE `reminder` SET `date`='$date', `subject`='$subject', `description`='$description', `email`='$email', `contact`='$contact', `sms`='$sms', `recurrence`='$recurrence' WHERE `id`='$id'; ";
	   
	   $run = mysqli_query($con,$qry);
	   
	   if($run == TRUE)
	   {
	      ?>
		  <script>
	       alert('Data Updated Successfully.');
           window.open('updateeform.php?sid=<?php echo $id; ?>','_self');
		   </script>
		   <?php
	   }
	   
	 
	



?>