<?php 

 include('../dbcon.php');
		
		
	 $id = $_REQUEST['sid'];
		
	 
	   $qry = "DELETE FROM `reminder` WHERE `id`='$id';";
	   
	   $run = mysqli_query($con,$qry);
	   
	   if($run == TRUE)
	   {
	      ?>
		  <script>
	       alert('Data Deleted Successfully.');
           window.open('Deletetimetable.php','_self');
		   </script>
		   <?php
	   }
	   
	 
	



?>