
    <?php


              session_start();
			  
			  if($_SESSION['uid'])
			  {
				 echo "";
			  }
			  else
			  {
				  header('location:  ../login.php');
			  }
			  
			  
	?>	

<?php
      
	  include('header.php');

?>
<hr/><br/>
     
	  
	  
	  <form action="view.php" method="POST">

	       <table border="1" align="center" width="30%" height="26%">
		         <tr>
	                   <td colspan="2" align="center"> <h3>Reminder</h3></td>			 
				 </tr>
		         <tr>
	                   <td >Select Date</td>
					  	 <td><input type="date" data-date-inline-picker="true" name="date"/></td> 
				 </tr>
		        
				  <tr>
	                   <td >Subject</td>
					  	 <td><select name="subject"  >
				 <option>---Select Subject--</option>
				 <option value="Android">Android</option>
				 <option value="PHP">PHP</option>
				 <option value="Java">Java</option>
				 <option value="JavaScript">JavaScript</option>
				 <option value="Maths">Maths</option>
				 
                 </select></td>		 
				 </tr>
		        
		         <tr>
	                  
					   <td colspan="2" align="center"><input type="submit" name="submit" value="Show Reminder"/></td>			 
				 </tr>						 
		   </table>
		  
	  
	  </form>
	  
	  
	 
	  
	  
</body>

</html>

<?php

if(isset($_POST['submit']))
{
	  $date = $_POST['date'];
	  $subject = $_POST['subject'];
	  
	  
	  include('../dbcon.php');

   
		
		
		$sql = "SELECT * FROM `reminder` WHERE `date`='$date' AND `subject`='$subject' ";
		$run = mysqli_query($con,$sql);
	
?>	 
<br><hr/><br>
<table align="center" width="80%" border="2px">
			 
			 <tr>
			        <td align="center"><b>Record No.</b></td>
					 <td align="center"><b>Date</b></td>
					  <td align="center"><b>Subject</b></td>
					   <td align="center"><b>Description</b></td>
					    <td align="center"><b>Email</b></td>
						 <td align="center"><b>Contact</b></td>
						  <td align="center"><b>SMS</b></td>
						   <td align="center"><b>Recurrence</b></td>
					
						    
			 </tr>
			 </table>
<?php
		 if(mysqli_num_rows($run)<1)
	   {
	      echo "<tr><td>No record found</td></tr>";
	   }
	   else
	   {
	       $count=0;
		   while($data = mysqli_fetch_assoc($run))
		   {
		     $count++;
			 ?>
			 <table align="center" width="80%" border="2px" >
			 
			 
			 <br>
			 
			 <tr>
			     <td align="center"><?php echo $count; ?></td>
					 
	             <td align="center"><?php echo $data['date']; ?></td>
				 <td align="center"><?php echo $data['subject']; ?></td>
				 <td align="center"><?php echo $data['description']; ?></td>
				 <td align="center"><?php echo $data['email']; ?></td>
				 <td align="center"><?php echo $data['contact']; ?></td>
				 <td align="center"><?php echo $data['sms']; ?></td>
				 <td align="center"><?php echo $data['recurrence']; ?></td>
				 
				 
				 
			 </tr>
			 </table>
			 <?php
		   }
	   }
   


		
}
?>