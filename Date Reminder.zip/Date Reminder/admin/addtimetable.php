

    <?php


              session_start();
			  
			  if($_SESSION['uid'])
			  {
				 echo "";
			  }
			  else
			  {
				  header('location:  ../login.php');
			  }
			  
			  
	?>	

<?php
      
	  include('header.php');

?>
<hr/><br/>
<table class="tab" align="center">
       
    <h3 align="center" style="color:blue;">Set Reminder Information</h3>
      <form method="post" action="addtimetable.php" enctype="multipart/form-data">
	   <tr>
	       <td>Select Date</td>
		   <td><input type="date" data-date-inline-picker="true" name="date" required /></td>
	  </tr>
	 <tr>
	     <td>Select Subject</td>
	     <td>
	        
 
				 <select name="subject"  required >
				 <option>---Select Subject--</option>
				 <option value="Android">Android</option>
				 <option value="PHP">PHP</option>
				 <option value="Java">Java</option>
				 <option value="JavaScript">JavaScript</option>
				 <option value="Maths">Maths</option>
				 
                 </select>
	    </td>
	</tr>
	<tr>
	       <td>Add Description</td>
		   <td><textarea type="text" name="description"  required>Enter text here...</textarea></td>
	  </tr>
	  <tr>
	       <td>Email Address</td>
		   <td><input type="email" name="email" id="email" pattern=".+@gmail.com" size="30"></td>
	  </tr>
	   <tr>
	       <td>Contact No.</td>
		   <td><input type="text" name="contact" required /></td>
	  </tr> <tr>
	       <td>SMS No.</td>
		   <td><input type="text" name="sms" /></td>
	  </tr>
	   <tr>
	       <td>Recurrence for next</td>
		   <td><input type="checkbox" name="recurrence" value="7days"><label>7days</label>
		       <input type="checkbox" name="recurrence" value="5days"><label>5days</label>
			   <input type="checkbox" name="recurrence" value="3days"><label>3days</label>
			   <input type="checkbox" name="recurrence" value="2days"><label>2days</label>
		   
		   </td>
	  </tr>
	  
	  
	<!--
	  
	  <tr>
	       <td>College</td>
		   <td><input type="text" name="college" required /></td>
	  </tr>
	   <tr>
	       <td>Course</td>
		   <td><input type="text" name="course" required /></td>
	  </tr>
	   <tr>
	       <td>Branch</td>
		   <td><input type="text" name="branch" required /></td>
	  </tr>
	   <tr>
	       <td>Session Year</td>
		   <td><input type="number" name="sessionyear" required /></td>
	  </tr>
	   <tr>
	       <td>Day</td>
		   <td><input type="text" name="day" required /></td>
	  </tr>
	    <tr>
	       <td>Period</td>
		   <td><input type="number" name="period" required /></td>
	  </tr>
	   <tr>
	       <td>Trainer Skill</td>
		   <td><input type="text" name="trainerskill" required /></td>
	  </tr>
	   <tr>
	       <td>Trainer Name</td>
		   <td><input type="text" name="trainername" required /></td>
	  </tr>
	  <tr>
	       <td>Image</td>
		   <td><input type="file" name="simg"  /></td>
	  </tr>
	   -->
	   <tr>
	       <td><br /></td>
		   <td><br/></td>
	   </tr>
	   <tr>
	       <br />
		   <td colspan="2" align="center"><input type="submit" name="submit" value="Confirm" /></td>
	  </tr>  
    </form>
</table>

<?php

     

     if(isset($_POST['submit']))
	 {
	    include('../dbcon.php');
		
		 $date = $_POST['date'];
		 $subject = $_POST['subject'];
		 $description = $_POST['description'];
		 $email = $_POST['email'];
		 $contact = $_POST['contact'];
		 $sms = $_POST['sms'];
		 $recurrence = $_POST['recurrence'];
		
		 
		
		
		
		
	/*     $college = $_POST['college'];
		 $course = $_POST['course'];
		 $branch = $_POST['branch'];
		 $sessionyear = $_POST['sessionyear'];
		 $day = $_POST['day'];
		 $period = $_POST['period'];
		 $trainerskill = $_POST['trainerskill'];
		 $trainername = $_POST['trainername'];
		 
		 $imagename = $_FILES['simg']['name'];
		 $tempname = $_FILES['simg']['tmp_name'];
		 
		 
		 move_uploaded_file($tempname,"../dataimg/$imagename");   */
		
	 
	   $qry = "INSERT INTO `reminder`(`date`,`subject`,`description`,`email`,`contact`,`sms`,`recurrence`) VALUES('$date','$subject','$description','$email','$contact','$sms','$recurrence') ";
	   
	   $run = mysqli_query($con,$qry);
	   
	   if($run == TRUE)
	   {
	      ?>
		  <script>
	       alert('Data Inserted Successfully.');
		   </script>
		   <?php
	   }
	   
	 }
	

?>