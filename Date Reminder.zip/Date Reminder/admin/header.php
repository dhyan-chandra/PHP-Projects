
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>header</title>

    <link href="../css/style.css" type="text/css" rel="stylesheet"/> 
     
	  <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
</head>
       
<body>


<hr/><br/>



<table>
       
	   
     
	 <tr>
	       <td class="back"> <h3><a href="admindash.php">Back</a></h3></td>
		   <td class="adminheader"><h1 style="color:red;">Welcome To Reminder Application</h1></td>
		    <td class="logout"><h3><a href="../login.php">Logout</a></h3></td>
			 
	 </tr>
	  <tr>
	  <td></td>
	     <td style="color:Green;"><center><?php echo "Today is " . date("l, "). date("Y/m/d");?></center></td>
		 <td></td>
	</tr>
	 
</table>








