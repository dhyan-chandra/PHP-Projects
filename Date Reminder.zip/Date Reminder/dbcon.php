<?php

 $con =  mysqli_connect('localhost','root','','rms');


   if($con == false)
{

   echo "Connection is not done.";

}
 
?>