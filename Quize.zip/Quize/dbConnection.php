<?php
//all the variables defined here are accessible in all the files that include this one
$con= new mysqli('localhost','root','','project')or die("Database Connection not found ".mysqli_error($con));

?>