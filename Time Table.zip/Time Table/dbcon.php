<?php

 $con =  mysqli_connect('localhost','root','','tms');


   if($con == false)
{

   echo "Connection is not done.";

}
 
?>