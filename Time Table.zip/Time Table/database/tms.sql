-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 29, 2019 at 01:40 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tms`
--
CREATE DATABASE IF NOT EXISTS `tms` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `tms`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `trainer`
--

CREATE TABLE IF NOT EXISTS `trainer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `college` varchar(50) NOT NULL,
  `course` varchar(50) NOT NULL,
  `branch` varchar(50) NOT NULL,
  `sessionyear` int(11) NOT NULL,
  `day` varchar(50) NOT NULL,
  `period` int(11) NOT NULL,
  `trainerskill` varchar(50) NOT NULL,
  `trainername` varchar(50) NOT NULL,
  `image` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `trainer`
--

INSERT INTO `trainer` (`id`, `college`, `course`, `branch`, `sessionyear`, `day`, `period`, `trainerskill`, `trainername`, `image`) VALUES
(8, 'Ashoka Institute', 'B.Tech', 'CSE', 3, 'Monday', 1, 'Ind. Manage.', 'Mr. Vishal', ''),
(9, 'Ashoka', 'B.Tech', 'CSE', 3, 'Monday', 2, 'Computer', 'Arvind Sir', ''),
(10, 'Ashoka Institute', 'B.Tech', 'CSE', 3, 'Monday', 3, 'Computer Network Lab', 'Mr. Amit Maurya ', ''),
(11, 'Ashoka Institute', 'B.Tech', 'CSE', 3, 'Monday', 4, 'Data Mining Lab', 'Dr. R. S. Yadav', ''),
(12, 'Ashoka Institute', 'B.Tech', 'CSE', 3, 'Monday', 5, 'Compiler Design', 'Mrs. Juli Singh', ''),
(13, 'Ashoka Institute', 'B.Tech', 'CSE', 3, 'Monday', 6, 'Computer Networks', 'Mr. Amit Maurya', ''),
(14, 'Ashoka Institute', 'B.Tech', 'CSE', 3, 'Monday', 7, 'Cyber Security', 'Mr. Arvind Kumar', ''),
(15, 'Ashoka Institute', 'B.Tech', 'CSE', 3, 'Monday', 8, 'Data Mining ', 'Dr. R. S. Yadav', ''),
(16, 'Ashoka Institute', 'B.Tech', 'CSE', 3, 'Tuesday', 1, 'Computer Networks', 'Mr. Amit Maurya', ''),
(17, 'Ashoka Institute', 'B.Tech', 'CSE', 3, 'Tuesday', 2, 'Computer Graphics', 'Mr. Arvind Kumar', ''),
(18, 'Ashoka Institute', 'B.Tech', 'CSE', 3, 'Tuesday', 3, 'Data Mining ', 'Dr. R. S. Yadav', ''),
(19, 'Ashoka Institute', 'B.Tech', 'CSE', 3, 'Tuesday', 4, 'Computer Networks', 'Mr. Amit Maurya', ''),
(20, 'Ashoka Institute', 'B.Tech', 'CSE', 3, 'Tuesday', 5, 'Compiler Design', 'Mrs. Juli Singh', ''),
(21, 'Ashoka Institute', 'B.Tech', 'CSE', 3, 'Tuesday', 6, 'Data Mining ', 'Dr. R. S. Yadav', ''),
(22, 'Ashoka Institute', 'B.Tech', 'CSE', 3, 'Tuesday', 7, 'Ind. Manage.', 'Mr. Vishal', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
