<?php
    function showdetails($college,$course,$branch,$sessionyear)
	{
		include('dbcon.php');
		
		$sql = "SELECT * FROM `trainer` WHERE `college`='$college' AND `course`='$course' AND `branch`='$branch' AND `sessionyear`='$sessionyear'";
		$run = mysqli_query($con,$sql);
		?>

			
			<div style="height:510px; width:1220; border:1px solid #CCCCCC; margin:auto" >
             <div style="height:510px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			             <div style="height:80px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                         
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                            <p><center><b>Monday</b></center></p>    
                          </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                             <p><center><b>Tuesday</b></center></p>   
                         </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                              <p><center><b>Wednesday</b></center></p>   
                         </div>
						 <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                               <p><center><b>Thursday</b></center></p>   
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                            <p><center><b>Friday</b></center></p>   
                          </div>
			             <div style="height:67px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                               <p><center><b>Saturday</b></center></p>   
                         </div>
             </div>
             <div style="height:510px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                <div style="height:80px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                           <p> <center> <b>Period 1</b><hr>
									 <b>09:00-09:45</b></center></p>
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
						  
						                      <?php
                                                     	if(mysqli_num_rows($run) > 0)
	                                                         {
		                                                     $count=0;
		                                                     while($data = mysqli_fetch_assoc($run))
		                                                        {
		                                                         $count++;
			                                                     if ($data['day']== 'Monday' &&  $data['period']=='1')
				                                                   {
				                                                    ?> <p><?php echo $data['trainerskill']; ?> <br><?php echo $data['trainername']; ?><br><?php echo $data['period']; ?></p><?php
				                                                    }	
															     }
	                                                         }  
                                                ?>															 
	                                                                     
                          </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                                       <?php
                                                     	if(mysqli_num_rows($run) > 0)
	                                                         {
		                                              $count=0;
		                                                 while($data = mysqli_fetch_assoc($run))
		                                                           {
		                                                  $count++;
			 
			

											              if ($data['day']== 'Tuesday' &&  $data['period']=='1')
				                                                   {
				                                                    ?> <p><?php echo $data['trainerskill']; ?> <br><?php echo $data['trainername']; ?><br><?php echo $data['period']; ?></p><?php
				                                                 
																   }	
																	 }
	     
	                                                          }       
	                                                       ?>                 
                         </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                               
                         </div>
						 <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                          </div>
			             <div style="height:67px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
              </div>
			  <div style="height:510px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                <div style="height:80px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                              <p> <center> <b>Period 2</b><hr><b>09:45-10:30</b></center></p>
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                             <?php if ($data['day']== 'Monday' &&  $data['period']=='2')
				                                                   {
				                                                    ?> <p><?php echo $data['trainerskill']; ?> <br><?php echo $data['trainername']; ?><br><?php echo $data['period']; ?></p><?php
				                                                    }
				                                                    ?>              
                          </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                                  <?php if ($data['day']== 'Tuesday' &&  $data['period']=='2')
				                                                   {
				                                                    ?> <p><?php echo $data['trainerskill']; ?> <br><?php echo $data['trainername']; ?><br><?php echo $data['period']; ?></p><?php
				                                                    }
				                                                    ?>                
                         </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                  
                         </div>
						 <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                          </div>
			             <div style="height:67px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
             </div>
             <div style="height:510px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                <div style="height:80px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                 <p> <center> <b>Period 3</b><hr><b>10:30-11:15</b></center></p>
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
						                  
                          </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                  
                         </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
						 <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                          </div>
			             <div style="height:67px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
              </div>
			  <div style="height:510px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
	                          <div style="height:80px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                               <p> <center> <b>Period 4</b><hr><b>11:15-12:00</b></center></p>
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                     
                          </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                
                         </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
						 <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                          </div>
			             <div style="height:67px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
             </div>
             <div style="height:510px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                  <div style="height:80px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                     <h1><center>Break</center></h1>
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                      <h1><center>Break</center></h1>
                          </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                           <h1><center>Break</center></h1>
                         </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                         <h1><center>Break</center></h1>
                         </div>
						 <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                           <h1><center>Break</center></h1>
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                               <h1><center>Break</center></h1>
                          </div>
			             <div style="height:67px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                            <h1><center>Break</center></h1>
                         </div>
              </div>
			   <div style="height:510px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                      <div style="height:80px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                               <p> <center> <b>Period 5</b><hr><b>01:00-01:45</b></center></p>
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                  <?php    if($data['day']=='Monday' &&  $data['period']=='5') 
								            {
									        ?>
			                                 <p> <center> <?php echo $data['trainerskill']; ?><br><?php echo $data['trainername']; ?>
									         </center></p>
											<?php } ?>
                          </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                 <?php    if($data['day']=='Tuesday' &&  $data['period']=='5') 
								            {
									        ?>
			                                 <p> <center> <?php echo $data['trainerskill']; ?><br><?php echo $data['trainername']; ?>
									         </center></p>
											<?php } ?>
                         </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
						 <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                          </div>
			             <div style="height:67px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
              </div>
			  <div style="height:510px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                  <div style="height:80px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                           <p> <center> <b>Period 6</b><hr><b>01:45-02:30</b></center></p>
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                <?php    if($data['day']=='Monday' &&  $data['period']=='6') 
								            {
									        ?>
			                                 <p> <center> <?php echo $data['trainerskill']; ?><br><?php echo $data['trainername']; ?>
									         </center></p>
											<?php } ?>
                          </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                  <?php    if($data['day']=='Tuesday' &&  $data['period']=='6') 
								            {
									        ?>
			                                 <p> <center> <?php echo $data['trainerskill']; ?><br><?php echo $data['trainername']; ?>
									         </center></p>
											<?php } ?>
                         </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
						 <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                          </div>
			             <div style="height:67px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
              </div>
			  <div style="height:510px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                 <div style="height:80px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                <p> <center> <b>Period 7</b><hr><b>02:30-03:15</b></center></p>
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                 <?php    if($data['day']=='Monday' &&  $data['period']=='7') 
								            {
									        ?>
			                                 <p> <center> <?php echo $data['trainerskill']; ?><br><?php echo $data['trainername']; ?>
									         </center></p>
											<?php } ?>
                          </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                    <?php    if($data['day']=='Tuesday' &&  $data['period']=='7') 
								            {
									        ?>
			                                 <p> <center> <?php echo $data['trainerskill']; ?><br><?php echo $data['trainername']; ?>
									         </center></p>
											<?php } ?>
                         </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
						 <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                          </div>
			             <div style="height:67px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
			  </div>
			  <div style="height:510px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                       <div style="height:80px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                              <p> <center> <b>Period 8</b><hr><b>03:15-04:00</b></center></p>
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                   <?php    if($data['day']=='Monday' &&  $data['period']=='8') 
								            {
									        ?>
			                                 <p> <center> <?php echo $data['trainerskill']; ?><br><?php echo $data['trainername']; ?>
									         </center></p>
											<?php } ?>
                          </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			                                  <?php    if($data['day']=='Tuesday' &&  $data['period']=='8') 
								            {
									        ?>
			                                 <p> <center> <?php echo $data['trainerskill']; ?><br><?php echo $data['trainername']; ?>
									         </center></p>
											<?php } ?>
                         </div>
			             <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
						 <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
						  <div style="height:70px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                          </div>
			             <div style="height:67px; width:120px; border:1px solid #CCCCCC; float:left; margin:auto" >
			 
                         </div>
			  </div>
			
</div>


 <?php
		
	}
	
	?>