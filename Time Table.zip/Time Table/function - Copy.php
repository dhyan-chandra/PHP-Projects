<?php
    function showdetails($college,$course,$branch,$sessionyear)
	{
		include('dbcon.php');
		
		$sql = "SELECT * FROM `trainer` WHERE `college`='$college' AND `course`='$course' AND `branch`='$branch' AND `sessionyear`='$sessionyear'";
		$run = mysqli_query($con,$sql);
		
		if(mysqli_num_rows($run) > 0)
		{
			$data = mysqli_fetch_assoc($run);
			?>
			<table border="1" style="width:25%" align="center">
			      <tr>
				      <th colspan="3">Time Table</th>
				</tr>
				
				 <tr>
				      <th>Branch</th>
					  <td><?php echo $data['branch']; ?></td>
				</tr>
				 <tr>
				      <th>Session Year</th>
					  <td><?php echo $data['sessionyear']; ?></td>
				</tr>
				      <th>Day</th>
					  <td><?php echo $data['day'];?></td>
				</tr>
				<tr>
				   <th>Period</th>
				   <td><?php echo $data['period']; ?></td>
				  </tr>
				  <tr>
				      <th>Trainer Skill</th>
					  <td><?php echo $data['trainerskill']; ?></td>
				</tr>
				 <tr>
				      <th>Trainer Name</th>
					  <td><?php echo $data['trainername']; ?></td>
				</tr>
				
			</table>
			
			<?php
			
		}
		else 
		{
			echo "<script> 
			            alert('No Student Found');
				</script>";
		}
		
	}
	
	?>