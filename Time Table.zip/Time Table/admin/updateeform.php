 <?php


              session_start();
			  
			  if($_SESSION['uid'])
			  {
				 echo "";
			  }
			  else
			  {
				  header('location:  ../login.php');
			  }
			  
			  
	?>	

<?php
      
	  include('header.php');
	  include('../dbcon.php');
	
	  $sid = $_GET['sid'];
	  
	  $qry = "SELECT * FROM `trainer` WHERE `id`='$sid'";
	  
	  $run = mysqli_query($con,$qry);
	  
	  $data = mysqli_fetch_assoc($run);
	  
	  

?>

<table class="tab" align="center">
      <form method="post" action="updatedata.php" enctype="multipart/form-data">
	  <tr>
	       <td>College</td>
		   <td><input type="text" name="college" value=<?php  echo $data['college'];   ?> required /></td>
	  </tr>
	   <tr>
	       <td>Course</td>
		   <td><input type="text" name="course" value=<?php  echo $data['course'];   ?> required /></td>
	  </tr>
	   <tr>
	       <td>Branch</td>
		   <td><input type="text" name="branch" value=<?php  echo $data['branch'];   ?> required /></td>
	  </tr>
	   <tr>
	       <td>Session Year</td>
		   <td><input type="number" name="sessionyear" value=<?php  echo $data['sessionyear'];   ?> required /></td>
	  </tr>
	   <tr>
	       <td>Day</td>
		   <td><input type="text" name="day" value=<?php  echo $data['day'];   ?> required /></td>
	  </tr>
	   <tr>
	       <td>Period</td>
		   <td><input type="number" name="period" value=<?php  echo $data['period'];   ?> required /></td>
	  </tr>
	   <tr>
	       <td>Trainer Skill</td>
		   <td><input type="text" name="trainerskill" value=<?php  echo $data['trainerskill'];   ?> required /></td>
	  </tr>
	   <tr>
	       <td>Trainer Name</td>
		   <td><input type="text" name="trainername" value=<?php  echo $data['trainername'];   ?> required /></td>
	  </tr>
	   <tr>
	       <td>Image</td>
		   <td><input type="file" name="simg"  /></td>
	  </tr>
	  
	   <tr>
	       <td><br /></td>
		   <td><br/></td>
	   </tr>
	   <tr>
	       <br />
		   <td colspan="2" align="center">
		   <input type="hidden" name="sid" value="<?php echo $data['id']; ?>" />
		   <input type="submit" name="submit" value="Submit" /></td>
	  </tr>
    </form>
</table>