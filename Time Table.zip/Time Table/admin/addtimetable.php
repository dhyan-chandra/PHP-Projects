

    <?php


              session_start();
			  
			  if($_SESSION['uid'])
			  {
				 echo "";
			  }
			  else
			  {
				  header('location:  ../login.php');
			  }
			  
			  
	?>	

<?php
      
	  include('header.php');

?>

<table class="tab" align="center">
      <form method="post" action="addtimetable.php" enctype="multipart/form-data">
	  <tr>
	       <td>College</td>
		   <td><input type="text" name="college" required /></td>
	  </tr>
	   <tr>
	       <td>Course</td>
		   <td><input type="text" name="course" required /></td>
	  </tr>
	   <tr>
	       <td>Branch</td>
		   <td><input type="text" name="branch" required /></td>
	  </tr>
	   <tr>
	       <td>Session Year</td>
		   <td><input type="number" name="sessionyear" required /></td>
	  </tr>
	   <tr>
	       <td>Day</td>
		   <td><input type="text" name="day" required /></td>
	  </tr>
	    <tr>
	       <td>Period</td>
		   <td><input type="number" name="period" required /></td>
	  </tr>
	   <tr>
	       <td>Trainer Skill</td>
		   <td><input type="text" name="trainerskill" required /></td>
	  </tr>
	   <tr>
	       <td>Trainer Name</td>
		   <td><input type="text" name="trainername" required /></td>
	  </tr>
	  <tr>
	       <td>Image</td>
		   <td><input type="file" name="simg"  /></td>
	  </tr>
	  
	   <tr>
	       <td><br /></td>
		   <td><br/></td>
	   </tr>
	   <tr>
	       <br />
		   <td colspan="2" align="center"><input type="submit" name="submit" value="Submit" /></td>
	  </tr>
    </form>
</table>

<?php

     

     if(isset($_POST['submit']))
	 {
	    include('../dbcon.php');
		
		
	     $college = $_POST['college'];
		 $course = $_POST['course'];
		 $branch = $_POST['branch'];
		 $sessionyear = $_POST['sessionyear'];
		 $day = $_POST['day'];
		 $period = $_POST['period'];
		 $trainerskill = $_POST['trainerskill'];
		 $trainername = $_POST['trainername'];
		 
		 $imagename = $_FILES['simg']['name'];
		 $tempname = $_FILES['simg']['tmp_name'];
		 
		 
		 move_uploaded_file($tempname,"../dataimg/$imagename");
		
	 
	   $qry = "INSERT INTO `trainer`(`college`,`course`,`branch`,`sessionyear`,`day`,`period`,`trainerskill`,`trainername`,`image`) VALUES('$college','$course','$branch','$sessionyear','$day','$period','$trainerskill','$trainername','$imagename') ";
	   
	   $run = mysqli_query($con,$qry);
	   
	   if($run == TRUE)
	   {
	      ?>
		  <script>
	       alert('Data Inserted Successfully.');
		   </script>
		   <?php
	   }
	   
	 }
	

?>