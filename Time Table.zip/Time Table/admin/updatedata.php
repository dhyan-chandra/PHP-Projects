<?php 

 include('../dbcon.php');
		
		
	     $college = $_POST['college'];
		 $course = $_POST['course'];
		 $branch = $_POST['branch'];
		 $sessionyear = $_POST['sessionyear'];
		 $day = $_POST['day'];
		 $period = $_POST['period'];
		 $trainerskill = $_POST['trainerskill'];
		 $trainername = $_POST['trainername'];
		 
		 $id = $_POST['sid'];
		 $imagename = $_FILES['simg']['name'];
		 $tempname = $_FILES['simg']['tmp_name'];
		 
		 
		 move_uploaded_file($tempname,"../dataimg/$imagename");
		
	 
	   $qry = "UPDATE `trainer` SET `college`='$college', `course`='$course', `branch`='$branch', `sessionyear`='$sessionyear', `day`='$day', `period`='$period', `trainerskill`='$trainerskill', `trainername`='$trainername', `image`='$imagename' WHERE `id`='$id'; ";
	   
	   $run = mysqli_query($con,$qry);
	   
	   if($run == TRUE)
	   {
	      ?>
		  <script>
	       alert('Data Updated Successfully.');
           window.open('updateeform.php?sid=<?php echo $id; ?>','_self');
		   </script>
		   <?php
	   }
	   
	 
	



?>