 
    <?php


              session_start();
			  
			  if($_SESSION['uid'])
			  {
				 echo "";
			  }
			  else
			  {
				 header('location:../login.php');
			  }
			  
			  
	?>		
	
	<?php 
	
	   include('header.php');
	   
	   ?>  
	   
	   <br />
	   <br/>
	   <div class="adminp">
	        <p><a href="addtimetable.php">Add Time Table Information</a></p>
			 <p><a href="updatetimetable.php">Update Time Table Information</a></p>
			 			  <p><a href="deletetimetable.php">Delete Time Table Information</a></p>
	   </div>
	   
	   </body>
	   </html>