  <?php


              session_start();
			  
			  if($_SESSION['uid'])
			  {
				 echo "";
			  }
			  else
			  {
				  header('location:  ../login.php');
			  }
			  
			  
	?>	

<?php
      
	  include('header.php');

?>

<table class="tab" align="center">

 <form method="post" action="updatetimetable.php" enctype="multipart/form-data">
	 
	   <tr>
	       <td>Enter College</td>
		   <td><input type="text" name="college" required /></td>
	  </tr>
	    <tr>
	       <td> Enter Course</td>
		   <td><input type="text" name="course" required /></td>
	  </tr>
	  <tr>
	       <td>Enter Branch</td>
		   <td><input type="text" name="branch" required /></td>
	  </tr>
	    <tr>
	       <td> Enter Session Year</td>
		   <td><input type="number" name="sessionyear" required /></td>
	  </tr>
	   <tr>
	       <br />
		   <td colspan="2" align="center"><input type="submit" name="submit" value="Submit" /></td>
	  </tr>
</form>
</table>


<?php

   if(isset($_POST['submit']))
   {
       include('../dbcon.php');
	   
	   $college = $_POST['college'];
	   $course = $_POST['course'];
	   $branch = $_POST['branch'];
	   $sessionyear = $_POST['sessionyear'];
	   
	   
	   $sql = "SELECT * FROM `trainer` WHERE `college` = '$college' AND `course` = '$course'  AND `branch` = '$branch' AND `sessionyear` = '$sessionyear' ";
	   
	   $run = mysqli_query($con,$sql);
	   
	   if(mysqli_num_rows($run)<1)
	   {
	      echo "<tr><td>No record found</td></tr>";
	   }
	   else
	   {
	       $count=0;
		   while($data = mysqli_fetch_assoc($run))
		   {
		     $count++;
			 ?>
			 <table align="center" width="80%" border="1px">
			 <tr>
			     <td align="center"><?php echo $count; ?></td>
				 <td align="center"><img src="../dataimg/<?php echo $data['image']; ?>" style="max-width:100px" /></td>
				 <td align="center"><?php echo $data['college']; ?></td>
				 <td align="center"><?php echo $data['course']; ?></td>
				 <td align="center"><?php echo $data['branch']; ?></td>
				 <td align="center"><?php echo $data['sessionyear']; ?></td>
				 <td align="center"><a href="updateeform.php?sid=<?php echo $data['id']; ?>">Edit</a></td>
			 </tr>
			 </table>
			 <?php
		   }
	   }
   
   }
?>
  