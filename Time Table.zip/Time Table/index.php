<html>
<head>
    <title>Time Table Management System</title>
	 <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  
</head>
<body>
      <p align="right"  ><a href="login.php">Admin Login</a></p>
	  <h1 align="center">Welcome to Time Table Management System</h1>
	  
	  <form action="index.php" method="POST">

	       <table border="1" align="center" width="30%" height="26%">
		         <tr>
	                   <td colspan="2" align="center"> <h3>Time Table</h3></td>			 
				 </tr>
		         <tr>
	                   <td >College</td>
					  	 <td><input type="text" name="college"/></td>		 
				 </tr>
		         <tr>
				       <td>Course</td>
					   <td><input type="text" name="course"/></td>			 
				 </tr>	
				  <tr>
	                   <td >Branch</td>
					  	 <td><input type="text" name="branch"/></td>		 
				 </tr>
		         <tr>
				       <td>Session Year</td>
					   <td><input type="text" name="sessionyear"/></td>			 
				 </tr>	
		         <tr>
	                  
					   <td colspan="2" align="center"><input type="submit" name="submit" value="Show Time Table"/></td>			 
				 </tr>						 
		   </table>
		  
	  
	  </form>
	  
	  
	 
	  
	  
</body>

</html>

<?php

if(isset($_POST['submit']))
{
	  $college = $_POST['college'];
	  $course = $_POST['course'];
	   $branch = $_POST['branch'];
	  $sessionyear = $_POST['sessionyear'];
	  
	  include('dbcon.php');
	  include('function.php');
	  
	  showdetails($college,$course,$branch,$sessionyear);
}
?>