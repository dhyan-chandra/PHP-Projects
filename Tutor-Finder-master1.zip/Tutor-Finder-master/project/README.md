There are many operations still to be completed like linking the faq's.
The Front-page is index.php and from here other files can be accessed.