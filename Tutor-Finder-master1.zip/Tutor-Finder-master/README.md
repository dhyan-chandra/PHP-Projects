# Tutor-Finder

This is a web-application which helps students find tutors based on their input location and subject.
This app uses PHP For backend and MySQL database.

# Features

* A student can search for tutor when he is only logged in.

* When logged in student can also request tutor of a subject.

* There is space for teacher to update when he logs in.

* There are features such as FAQ's included.

* Database file tutor.sql is also included.
