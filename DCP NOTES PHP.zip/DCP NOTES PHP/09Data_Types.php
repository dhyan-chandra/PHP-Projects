<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php

/*
______________________________________________________________________________________________________________________________                        
						                     Data Types
_______________________________________________________________________________________________________________________________


                  PHP supports the following data types:

                          1.   String  --->   Strings are sequences of characters
						  2.   Integer ----> Integers are whole numbers, without a decimal point (..., -2, -1, 0, 1, 2, ...).
						  3.   Float ----->Floating point numbers (also known as "floats", "doubles", or "real numbers") are decimal or fractional numbers
						  4.   Boolean ---->   either 1 (true) or 0 (false).
						  5.   Array   -----   An array is a variable that can hold more than one value at a time.
						  6.   Object   ----->   Read in OOPs 
						  7.   NULL   ------>   The special NULL value is used to represent empty variables
						 
						 




*/

?>

<?php 
/*

   // String
   $x = "Hello world!";
   $y = 'Hello world!';

   echo $x;
   echo "<br>"; 
   echo $y;

*/


?>


<?php

/*

// String 

$a = 'Hello world!';
echo $a;
echo "<br>";
 
$b = "Hello world!";
echo $b;
echo "<br>";
 
$c = 'Stay here, I\'ll be back.';
echo $c;

*/

?>


<?php
/*

// Integer 
 
$x = 5985;
var_dump($x);       //   var_dump() function returns the data type and value

*/
?>

<?php

/*

// integer

$a = 123; // decimal number
var_dump($a);
echo "<br>";
 
$b = -123; // a negative number
var_dump($b);
echo "<br>";
 
$c = 0x1A; // hexadecimal number
var_dump($c);
echo "<br>";
 
$d = 0123; // octal number
var_dump($d);


*/

?>

<?php 

/*
// float

$x = 10.365;
var_dump($x);

*/
?>


<?php

/*

// NULL

$x = "Hello world!";
$x = null;
var_dump($x);


*/

?>



<?php

/*

// Array

$colors = array("Red", "Green", "Blue");
var_dump($colors);
echo "<br>";
 
$color_codes = array(
    "Red" => "#ff0000",
    "Green" => "#00ff00",
    "Blue" => "#0000ff"
);
var_dump($color_codes);

*/
?>

<?php
/*

// OBject
  
  
  class greeting{      // Class Declration
    // properties
    public $str = "Hello World!";
    
    // methods
    function show_greeting(){
        return $this->str;
    }
}
 
// Create object from class
$message = new greeting;
var_dump($message);

*/

?>


</body>
</html>
