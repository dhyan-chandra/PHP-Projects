<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php

/*
______________________________________________________________________________________________________________________________                        
						                   Constants
										   
											 
		    Constants are like variables except that once a defined , cannot be changed.
			
			Two Types------>
			
			1...Using define() function
            2....Using const keyword
			
			
			
			
			
			
Syntax--->


            define(name, value, case-insensitive)



Parameters:

            name:                  Name of the constant
            value:                 value of the constant
            case-insensitive:      Specifies whether the constant name should be case-insensitive. Default is false
_______________________________________________________________________________________________________________________________


						 
*/

?>




<?php 

/*

define("MESSAGE","Welcome in PHP");  
echo MESSAGE;  // Case Senstive 

*/

?>


<?php 

/*
define("MESSAGE","Welcome in PHP", false);  
echo MESSAGE;  // Case Senstive ,  ByDefault is false

*/

?>



<?php 


/*

define("MESSAGE","Welcome in PHP", true);  
echo message;  // Case inSenstive 

*/
?>


<?php  

/*
define("MESSAGE","Welcome in PHP",true);//not case sensitive  
echo MESSAGE . "<br>";  
echo message;  

*/
?>  


<?php  

/*
define("MESSAGE","Welcome in PHP",false);// case sensitive  
echo MESSAGE . "<br>";  
echo message;  

*/


?>  





<?php

/*

define("MSG", "Welcome in PHP !");

function Test() {
    echo MSG;
}
 
Test();


*/

?>












</body>
</html>
