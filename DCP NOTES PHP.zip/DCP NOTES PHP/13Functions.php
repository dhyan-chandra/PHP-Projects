<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php

/*
______________________________________________________________________________________________________________________________                        
						                Functions
										
	Diff--->>
	
	
	1.     Function is a piece of code or set of instruction that can be reused many times.
	2.     There are thousands of built-in functions in PHP.
	
	
	
	Types of Function---->
	
	
	1.     User Defined 
	2.     Pre Defined
	
	
	
	User Defined Function----->
	
	
	            Syntax--->
				     
					           function functionName() 
							   {
                                     code to be executed;
                               }
				
				        
										   
_______________________________________________________________________________________________________________________________


						 
*/



?>






<?php  



/*
_______________________________________________________________________________________________________________________________



	User Defined Function----->
	
	
	            Syntax--->
				     
					           function functionName() 
							   {
                                     code to be executed;
                               }
				
				        
										   
_______________________________________________________________________________________________________________________________


// EXAMPLE-1---->


function Msg()   //   function creation
{
    echo "Hello world!";
}

 Msg(); // call the function


						 
*/



?>




<?php 

// EXAMPLE-2----> 

/*
  
function msg($name)
{  
   echo "Hello $name ! Welcome in PHP<br/>";  
}  



msg("Sonoo");  
msg("Vimal");  
msg("John");  

*/

?>





<?php  

// EXAMPLE-3---->

/*

function msg($name,$age)
{  
   echo "Hello $name!  you are $age years old<br/>";  
}  

msg("Sonoo",27);  
msg("Vimal",29);  
msg("John",23);  


*/

?>  



<?php  


// EXAMPLE-4---->


/*


// Call BY Reference  Program

function adder(&$str2)  
{  
    $str2 .= 'Navodaya';  
}  



$str = 'Hello ';  



adder($str);  
echo $str;  


*/


?>  







<?php 

// EXAMPLE-5---->

/*
 
function msg($name="Raj")
{  
   echo "Hello $name<br/>";  
} 


 
msg("Amit");  
msg();               //passing no value  
msg("John");  

*/

?>








<?php 

// EXAMPLE-6---->

/*
 
function cube($n)
{  
    return $n*$n*$n;  
}  

echo "Cube of 3 is: ".cube(3);  

*/

?>  





<?php

// EXAMPLE-7---->

/*

function sum($x, $y) 
{
    $z = $x + $y;
    return $z;
}

echo "Value of (5 + 10) = " . sum(5, 10) . "<br>";
echo "Sum of 7 + 13 = " . sum(7, 13) . "<br>";
echo "Addition of 2 + 4 = " . sum(2, 4);

*/

?>




<?php  


      // EXAMPLE-8---->
       
	  /* 
         
        
		 function add($x, $y) 
		 {  
            $sum = $x + $y;  
            echo "Sum of two numbers is = $sum <br><br>";  
         }   
           
  
           
         function sub($x, $y) 
		 {  
            $diff = $x - $y;  
            echo "Difference between two numbers is = $diff";  
         }   
         
		 
		 
		 add(467, 943); 
		
		 sub(943, 467);
		 
		
		
		*/ 
  ?>  
  





<?php  

// EXAMPLE-9---->

/*

function cube($n)
{  
    return $n*$n*$n;  
}  
echo "Cube of 3 is: ".cube(3);  


*/
?>  


<?php

// EXAMPLE-10---->


/*

// Maximum Number between Numbers---

function maximum($x, $y) {
    
    if ($x > $y) { 
        
        return $x;
    } else {
        
        return $y;
    }
}

$a = 23;
$b = 32;

$val = maximum($a, $b);
echo "The max of $a and $b is $val \n";


*/
?>


<?php



//Implicit values Program

/*

function power($a, $b=2) {

    if ($b == 2) {
    
        return $a * $a;
    }

    $value = 1;

    for ($i = 0; $i < $b; $i++) {
    
        $value *= $a;
    }
    
    return $value;
}

$v1 = power(5);
$v2 = power(5, 4);

echo "5^2 is $v1 <br>";
echo "5^4 is $v2 \n";


*/

?>



<?php

// Swap Program

/*

function swap(&$a, &$b) {

    $temp = $a;
    $a = $b;
    $b = $temp;
    echo "Inside the swap function:<br>";
    echo "\$a is $a <br>";
    echo "\$b is $b <br>";
}

$a = 4;
$b = 7;

echo "Outside the swap function: <br>";
echo "\$a is $a <br>";
echo "\$b is $b <br>";

swap($a, $b);

echo "Outside the swap function:<br>";
echo "\$a is $a <br>";
echo "\$b is $b <br>";

*/

?>



<?php


// Factorial Program

/*

function factorial($n) 
{

    if ($n==0) 
	{
    
        return 1;
    }
	 else 
	 {
    
        return $n * factorial($n - 1);
    }
}

echo factorial(4). "<br>";
echo factorial(10), "<br>";

*/

?>


</body>
</html>
