<?php
  include_once('Connection.php');
 ?>


<?php 
// Test 1---->   first check data fetch from the name attribute or not 

/*

if(isset($_POST['submit']))
{

 echo  $_POST['name'];
 echo  $_POST['email'];
 echo  $_POST['address'];
 echo  $_POST['admission'];
}

*/

?>



<?php 
// Test 2---->  fetch data transfer to variable and input data stored in database 

/*

if(isset($_POST['submit']))
{

 $name =  $_POST['name'];
 $email=  $_POST['email'];
 $add  =  $_POST['address'];
 $adm  =  $_POST['admission'];
 
 mysql_query("insert into stu_record (name,email,address,admission_date) values(' $name','$email','$add','$adm ')");
}

*/

?>



<?php 
// Test 3---->  Userfrendily message show on screen after data insert in tablle



if(isset($_POST['submit']))
{

 $name =  $_POST['name'];
 $email=  $_POST['email'];
 $add  =  $_POST['address'];
 $adm  =  $_POST['admission'];
 
 if(mysql_query("insert into stu_record (name,email,address,admission_date) values(' $name','$email','$add','$adm ')"))
 {

        echo('data inserted in database, Thank you!!');	 
	 
 }
}



?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<form method="post">

<p>Name:<br /> <input type="text" name="name" /></p>
<p>Email :<br /><input type="text" name="email" /></p>
<p>Address:<br /> <input type="text" name="address" /></p>
<p>Admission Date: <br /><input type="text" name="admission" /></p>
<p><input type="submit" name="submit" value="Submit" /></p>



</form>


</body>
</html>