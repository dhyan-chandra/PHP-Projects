<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php

/*
______________________________________________________________________________________________________________________________                        
                                       String
									   
									   
							 string is a sequence of characters
							 
							 
							 
							 
						1.	 single quoted
						2.   double quoted
							   
_______________________________________________________________________________________________________________________________


                    
						 
*/


?>




<?php 

/*
 
$str1 = 'Hello text   
         multiple line  
         text within single quoted string';  


$str2 = 'Using double "quote" directly inside single quoted string';

$str3="Using double \"quote\" with backslash inside double quoted string";   

$str4 = 'Using escape sequences \n in single quoted string';
$str5 =  "Using escape sequences \n in double quoted string";    

echo  " $str1  <br/>  $str2  <br/>  $str3   <br/>  $str4 <br/>  $str5 ";  



*/

?>  



</body>
</html>
