<?php

/*
______________________________________________________________________________________________________________________________                        
                                       POST Form
									   
									   
			1.	Post request is widely used to submit form.
			2.   data passed through post request is not visible on the URL browser so it is secured.
			3.    ______________________________________________________________________________________________________________________________


                    
						 
*/


?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>


<form action="19login_post.php" method="post"> 
  
<table>   
       <tr><td>Name:</td><td> <input type="text" name="name"/></td></tr>  
       <tr><td>Password:</td><td> <input type="password" name="password"/></td></tr>   
       <tr><td colspan="2"><input type="submit" name="Submit" value="login"/>  </td></tr>  
</table>  


</form>   

</body>
</html>
