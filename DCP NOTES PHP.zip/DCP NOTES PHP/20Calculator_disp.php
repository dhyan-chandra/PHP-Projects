<?php
$num1 = $_POST['num1'];
$num2 = $_POST['num2'];
$func = $_POST['function'];
if (!$num1="" || !$num2="")
{
  die("Value Cannot Be Null");
  exit();
}
else
{
  switch ($func) 
  {
	 case "+":
	          $result = $_POST['num1'] + $_POST['num2'];
		      break;
	 case "-":
	          $result = $_POST['num1'] - $_POST['num2'];
		      break;
	 case "*":
		      $result = $_POST['num1'] * $_POST['num2'];
		      break;
	 case "/":
		      $result = $_POST['num1'] / $_POST['num2'];
			  break;
  }
echo "Answer = " .$result;
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>


</body>
</html>