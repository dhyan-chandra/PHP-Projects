<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php

/*
______________________________________________________________________________________________________________________________                        
						                Array		
							
							
	Types of Array --->
	
	
	1.  Indexed Array
	2.  Associative Array
	3.  Multidimensional Array
							   
_______________________________________________________________________________________________________________________________




______________________________________________________________________________________________________________________________          
                                       Indexed Array  
									   
									   
	Syntax----
	
	
	
	1.          $season=array("summer","winter","spring","autumn"); 
	
	
	
	2.           $season[0]="summer";  
                 $season[1]="winter";  
                 $season[2]="spring";  
                 $season[3]="autumn"; 
				             
______________________________________________________________________________________________________________________________                        
						 
*/


?>



<?php 
/*
 
$season=array("summer","winter","spring","autumn");  
echo " <b> Season are:</b>  $season[0], $season[1], $season[2] and $season[3]";  

*/

?> 




<?php  

/*

$season[0]="summer";  
$season[1]="winter";  
$season[2]="spring";  
$season[3]="autumn";  
echo "Season are: $season[0], $season[1], $season[2] and $season[3]";  

*/

?>  



<?php

/*
______________________________________________________________________________________________________________________________          
                                     Associative Array
									 
									 ( Key => Value )
									 
									 
									 
				
	1.                     $salary=array("Sonoo"=>"350000","John"=>"450000","Kartik"=>"200000");  
	
	
	2.                    $salary["Sonoo"]="350000";  
                          $salary["John"]="450000";  
                          $salary["Kartik"]="200000";  
				             
______________________________________________________________________________________________________________________________      

*/

?>



<?php    


/*

$salary=array("Sonoo"=>"350000","John"=>"450000","Kartik"=>"200000");    


echo "Sonoo salary: ".$salary["Sonoo"]."<br/>";  

echo "John salary: ".$salary["John"]."<br/>";  

echo "Kartik salary: ".$salary["Kartik"]."<br/>";  

*/

?>  




<?php    
/*

$salary["Sonoo"]="350000";
    
$salary["John"]="450000";
    
$salary["Kartik"]="200000";
    
echo "Sonoo salary: ".$salary["Sonoo"]."<br/>";
  
echo "John salary: ".$salary["John"]."<br/>";
  
echo "Kartik salary: ".$salary["Kartik"]."<br/>";  


*/
?>


<?php    
/*

$salary=array("Sonoo"=>"550000","Vimal"=>"250000","Ratan"=>"200000");  


foreach($salary as $k => $v) 
{  
    echo "Key: " .$k. " Value: " .$v. "<br/>";  
}  


*/
?> 


<?php

/*
______________________________________________________________________________________________________________________________          
                                    Multidimensional Array ( array of arrays)
______________________________________________________________________________________________________________________________      

*/

?>


<?php


/*    


$emp = array  
  (  
  array(1,"sonoo",400000),  
  array(2,"john",500000),  
  array(3,"rahul",300000)  
  );  
  
 for ($row = 0; $row < 3; $row++)
 {  
  for ($col = 0; $col < 3; $col++) 
  {  
    echo $emp[$row][$col]."  ";  
  }  
  echo "<br/>";  
} 


*/ 
?> 


<?php



/*
         $marks = array( 
            "mohammad" => array (
               "physics" => 35,
               "maths" => 30,	
               "chemistry" => 39
            ),
            
            "qadir" => array (
               "physics" => 30,
               "maths" => 32,
               "chemistry" => 29
            ),
            
            "zara" => array (
               "physics" => 31,
               "maths" => 22,
               "chemistry" => 39
            )
         );
         
         
		 
		 
         echo "Marks for mohammad in physics : " ;
         echo $marks['mohammad']['physics'] . "<br />"; 
         
         echo "Marks for qadir in maths : ";
         echo $marks['qadir']['maths'] . "<br />"; 
         
         echo "Marks for zara in chemistry : " ;
         echo $marks['zara']['chemistry'] . "<br />"; 
  
  
     */
      ?>   





 


</body>
</html>
