<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php

/*
______________________________________________________________________________________________________________________________                        
                                 array_change_key_case()	
								 
					Changes all keys in an array to lowercase or uppercase
							   
_______________________________________________________________________________________________________________________________


                    
						 
*/


?>

<?php

/*

$age = array(" Amit "=>"35","Sohan"=>"37","Mohan"=>"43");

print_r(array_change_key_case($age,CASE_UPPER));

echo "<br>";

print_r(array_change_key_case($age,CASE_LOWER));


*/

?>

<?php

/*

$pets=array("a"=>"Cat","B"=>"Dog","c"=>"Horse","b"=>"Bird");

print_r(array_change_key_case($pets,CASE_UPPER));

*/

?>




<?php

/*
______________________________________________________________________________________________________________________________                        
                                array_chunk()	
								
					Splits an array into chunks of arrays
							   
_______________________________________________________________________________________________________________________________


                   						 
*/


?>


<?php

/*

$cars=array("Volvo","BMW","Toyota","Honda","Mercedes","Opel");

print_r(array_chunk($cars,2));

*/

?>


<?php

/*
______________________________________________________________________________________________________________________________                        
                                    array_combine()	
									
			Creates an array by using the elements from one "keys" array and one "values" array
_______________________________________________________________________________________________________________________________
                  						 
*/

?>



<?php

/*

$fname=array("Peter","Ben","Joe");

$age=array("35","37","43");

$c=array_combine($fname,$age);

print_r($c);




*/

?>



<?php

/*
______________________________________________________________________________________________________________________________                        
                                    array_merge()	
									
						Merges one or more arrays into one array
_______________________________________________________________________________________________________________________________
                  						 
*/

?>


<?php

/*

$a1=array("red","green");

$a2=array("blue","yellow");

print_r(array_merge($a1,$a2));

*/

?>

<?php

/*
______________________________________________________________________________________________________________________________                        
                                  
								  sort()	
								  
								  
					Sorts an indexed array in ascending order
_______________________________________________________________________________________________________________________________
                  						 
*/

?>



<?php

/*

$numbers=array(4,6,2,22,11);

sort($numbers);

$arrlength=count($numbers);

for($x=0;$x<$arrlength;$x++)
{
  
  echo $numbers[$x];
  
  echo "<br>";
  
}

*/
  
?>

<?php

/*
______________________________________________________________________________________________________________________________                        
                                  sizeof() 
								 
					function returns the number of elements in an array.
_______________________________________________________________________________________________________________________________
                  						 
*/

?>


<?php

/*


$cars=array("Volvo","BMW","Toyota");

echo sizeof($cars);


*/


?>


<?php

/*
______________________________________________________________________________________________________________________________                        
                                array_count_values()	
								
						Counts all the values of an array
_______________________________________________________________________________________________________________________________
                  						 
*/

?>




<?php

/*

$a=array("A","Cat","Dog","A","Dog");

print_r(array_count_values($a));


*/
?>


<?php

/*
______________________________________________________________________________________________________________________________                        
                                array_diff()	
								
				Compare arrays, and returns the differences (compare values only)
_______________________________________________________________________________________________________________________________
                  						 
*/

?>



<?php

/*


$a1 = array("a" => "red" , "b" => "green" , "c" => "blue" , "d" => "yellow" );

$a2 = array("e" => "red" , "f" => "green" , "g" => "blue" );

$result = array_diff( $a1 , $a2 );

print_r( $result );


*/

?>




<?php

/*
______________________________________________________________________________________________________________________________                        
                                array_diff_assoc()	
								
								
								
				Compare arrays, and returns the differences (compare keys and values)
				
				
				Return an array that contains the entries from array1 that are not present in array2 or array3, etc.
_______________________________________________________________________________________________________________________________
                  						 
*/

?>


<?php

/*
$a1 = array( "a" => "red" , "b" => "green" , "c" => "blue" , "d" => "yellow");
$a2 = array( "a" => "red" , "f" => "green" , "g" => "blue" );
$a3 = array( "h" => "red" , "b" => "green" , "g" => "blue" );

$result = array_diff_assoc( $a1 , $a2 , $a3 );
print_r( $result );

*/
?>





<?php

/*
______________________________________________________________________________________________________________________________                        
                             array_diff_key()	
							 
							 
			Compare arrays, and returns the differences (compare keys only)
_______________________________________________________________________________________________________________________________
                  						 
*/

?>



<?php

/*

$a1 = array ( "a" => "red" , "b" => "green" , "c" => "blue" );
$a2 = array ( "a" => "red" , "c" => "blue"  ,  "d" => "pink" );

$result = array_diff_key( $a1 , $a2 );
print_r( $result );

*/

?>



<?php

/*
______________________________________________________________________________________________________________________________                        
                             array_fill()	
							 
							 
					Fills an array with values
					
					
		Syntax---->			array_fill(index,number,value);
_______________________________________________________________________________________________________________________________
                  						 
*/

?>



<?php



$a1=array_fill(3,4,"blue");

$b1=array_fill(0,1,"red");

print_r($a1);

echo "<br>";

print_r($b1);




?>



<?php

/*
______________________________________________________________________________________________________________________________                                   array_intersect()	
 
 
                    Compare arrays, and returns the matches (compare values only)
_______________________________________________________________________________________________________________________________
                  						 
*/

?>



<?php

/*

$a1=array("a"=>"red","b"=>"green","c"=>"blue","d"=>"yellow");

$a2=array("e"=>"red","f"=>"green","g"=>"blue");

$result=array_intersect($a1,$a2);

print_r($result);


*/
?>





<?php

/*
______________________________________________________________________________________________________________________________                                
                                         array_push()	


                       Inserts one or more elements to the end of an array
_______________________________________________________________________________________________________________________________
                  						 
*/

?>


<?php

/*

$a = array(" red "," green ");

array_push( $a , "blue" , "yellow" );

print_r( $a );



*/
?>




<?php

/*
______________________________________________________________________________________________________________________________                                
                                     array_pop()	
									 
									 
									 
						Deletes the last element of an array
_______________________________________________________________________________________________________________________________
                  						 
*/

?>




<?php

/*

$a = array(" red "," green "," blue ");

array_pop( $a );

print_r( $a );



*/
?>



<?php

/*
______________________________________________________________________________________________________________________________                                
                                   array_rand()
								   
								   
					Returns one or more random keys from an array
_______________________________________________________________________________________________________________________________
                  						 
*/

?>



<?php

/*


$a = array( " 1 " ," 2 " , " 3 " , " 4 " , " 5 " );

$random_keys = array_rand( $a , 4 );

echo $a[ $random_keys[0] ]."<br>";
echo $a[ $random_keys[1] ]."<br>";
echo $a[ $random_keys[2] ]."<br>";
echo $a[ $random_keys[3] ]."<br>";


echo $a[ $random_keys[0] ]. $a[ $random_keys[1] ]. $a[ $random_keys[2] ]. $a[ $random_keys[3] ]."<br>";



*/

?>




<?php

/*
______________________________________________________________________________________________________________________________                                
                                  array_unique()	
								  
					Removes duplicate values from an array
_______________________________________________________________________________________________________________________________
                  						 
*/

?>



<?php

/*

$a = array( "a" => "red" , "b" => "green" , "c" => "red" );


print_r( array_unique($a));


*/


?>


<?php

/*
______________________________________________________________________________________________________________________________

                                in_array()	

                Checks if a specified value exists in an array
_______________________________________________________________________________________________________________________________
                  						 
*/

?>

<?php

/*

$people = array("Peter", "Joe", "Glenn", "Cleveland", "23");

if (in_array("23", $people, TRUE))       // Returns TRUE if the value is found in the array, or FALSE otherwise
  {
  echo "$people[4] Match found<br>";
  }
else
  {
  echo "Match not found<br>";
  } 
if (in_array("Glenn",$people, TRUE))
  {
  echo "Match found<br>";
  }
else
  {
  echo "Match not found<br>";
  }

if (in_array(23,$people, TRUE))
  {
  echo "Match found<br>";
  }
else
  {
  echo "Match not found<br>";
  }

*/

?>




<?php

/*
______________________________________________________________________________________________________________________________

                                range()	
								
					Creates an array containing a range of elements
					
					
					
					
					Syntax--->
                               range(low,high,step)
							   
							   
							   
			low	---->    Required.----->   Specifies the lowest value of the array
            high---->	Required.----->  Specifies the highest value of the array
            step---->	Optional.-----> Specifies the increment used in the range. Default is 1
_______________________________________________________________________________________________________________________________
                  						 
*/

?>



<?php
/*

$number = range( 0 , 50 , 10 );

print_r ( $number );

*/
?>




</body>
</html>
