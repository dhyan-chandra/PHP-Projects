<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<?php 

/*   
______________________________________________________________________________________________________________________________                        
						                      $GLOBALS[index]
_______________________________________________________________________________________________________________________________

  1.       PHP also stores all global variables in an array called $GLOBALS[index].
  2.       The index holds the name of the variable.
  3.       This array is accessible within functions and can be used to update global variables directly.


*/


?>



<?php
    $x = 17;
    $y = 50;

    function myTest() 
	{
        $GLOBALS['y'] = $GLOBALS['x'] + $GLOBALS['y'];    //  $GLOBALS[index]
    } 

    myTest();
    echo $y;
?>

</body>
</html>
