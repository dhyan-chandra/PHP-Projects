
<?php 
/*


--------------------------------------------------------------------------------------------------------------------
                                                Form Validation
												
												
					   Form Validation is important to protect your form from hackers and spammers.
					   
					   
					   
					                         $_SERVER["PHP_SELF"] variable
											 
											 
											 
					1.   sends the submitted form data to the page itself, instead of jumping to a different page. 
					 
				    2.	 This way, the user will get error messages on the same page as the form.
					 
					 
					 
					 
					                           htmlspecialchars() function
											   
									
					1.     converts special characters to HTML entities.
					2.     means that it will replace HTML characters like < and > with &lt; and &gt;.
					3.     This prevents attackers from exploiting the code by injecting HTML or Javascript code (Cross-site Scripting attacks) in forms.
					
					
					
					
					                             $_SERVER["REQUEST_METHOD"]
												 
												 
												 
					1.     If the REQUEST_METHOD is POST, then the form has been submitted - and it should be validated.
			
					
					 

--------------------------------------------------------------------------------------------------------------------


*/
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<?php


$name = $email = $gender = $comment = $website = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
  $name = test_input($_POST["name"]);
  $email = test_input($_POST["email"]);
  $website = test_input($_POST["website"]);
  $comment = test_input($_POST["comment"]);
  $gender = test_input($_POST["gender"]);
}

function test_input($data) 
{
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>

<h2>PHP Form Validation Example</h2>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
 
  Name: <input type="text" name="name">
  <br><br>

  E-mail: <input type="text" name="email">
  <br><br>

  Website: <input type="text" name="website">
  <br><br>

  Comment: <textarea name="comment" rows="5" cols="40"></textarea>
  <br><br>

  Gender:
  <input type="radio" name="gender" value="female">Female
  <input type="radio" name="gender" value="male">Male
  <br><br>

  <input type="submit" name="submit" value="Submit">  

</form>

<?php
echo "<h2>Your Input:</h2>";
echo $name;
echo "<br>";
echo $email;
echo "<br>";
echo $website;
echo "<br>";
echo $comment;
echo "<br>";
echo $gender;
?>

    
</body>
</html>
