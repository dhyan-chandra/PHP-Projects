<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php 

/*

_______________________________________________________________________________________________________________________________                        
						                       Variables Scope
_______________________________________________________________________________________________________________________________
			                 

Scope of a variable is the part of the script where the variable can be used.

PHP has three different variable scopes:

1.   global  ----->   A variable declared outside a function has a GLOBAL SCOPE and can only be accessed outside a function
2.   local   ----->   A variable declared within a function has a LOCAL SCOPE and can only be accessed within that function
3.   static  ----->   Normally, when a function is completed/executed, all of its variables are deleted. However, sometimes we  
                      want a local variable NOT to be deleted. We need it for a further job. To do this, use the static keyword                      when you first declare the variable.



NOTE----->


    Local variables with the same name in different functions, because local variables are only recognized by the function in     which they are declared.





*/

?>


<?php

/*


         $x = 5;     // global scope
 
         function myTest() 
		 {
             
               echo "<p>Variable x inside function is: $x</p>";    //   GLOBAL SCOPE can not be accessed in side a function
         } 
         
		 myTest();

         echo "<p>Variable x outside function is: $x</p>";       //GLOBAL SCOPE can be accessed outside a function

*/

?>







<?php

         /*

        function myTest() 
		{
            $x = 5;         // local scope
            echo "<p>Variable x inside function is: $x</p>";     // LOCAL SCOPE can be accessed within the function
        } 
        myTest();

        echo "<p>Variable x outside function is: $x</p>";        // LOCAL SCOPE can not be accessed within the function

       */
?>



<?php
       

	   function myTest() 
	   {
          static $x = 0;
          echo $x;
          $x++;
       }

        myTest();
        echo "<br>";

        myTest();
        echo "<br>";
        myTest();


?> 






</body>
</html>
