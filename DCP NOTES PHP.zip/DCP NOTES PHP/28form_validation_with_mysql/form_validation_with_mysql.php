<?php 

  include_once('Connection.php');

?>


<?php 

/*

 the filter_var function filters a variable with the specified filters

1.   FILTER_VALIDATE_EMAIL
2.   FILTER_VALIDATE_INT


*/
?>




<?php 
// Test 1---->  form validation

/*

if(isset($_POST['submit']))
{

 $user =  $_POST['username'];
 $pass=  $_POST['password'];
 $pass_len= strlen($pass);    // count the string length
 $email  =  $_POST['email'];
 $phone  =  $_POST['phone'];

 if(empty($user))
 {
    $msg = "Please enter User Name !";	
 }  
 else if(empty($pass))
 {
    $msg = "Please enter Password !";	
 }  
 else if($pass_len<=6)
 {
    $msg = "Password should be more than 6 charecter !";	
 }  
 
 else if(empty($email))          
 {
    $msg = "Please enter Email !";	
 }  
 else if(!filter_var($email,FILTER_VALIDATE_EMAIL))
 {
      $msg = "Please enter valid Email !";
  }
 else if(empty($phone))
 {
    $msg = "Please enter Phone !";	
 } 
 
 else 
 {
	$msg1= "Successfully Submitted !"; 
	 
  } 
}

*/

?>



<?php 
// Test 2---->  

/*
     1.      when all field are validate than sucessfully  message are display by else statement.
	 2.      But in standered way ---- mysql_query are written in else statement after all field validation.

*/
?>


<?php 

//test 2-----

/*


if(isset($_POST['submit']))
{

 $user =  $_POST['username'];
 $pass=  $_POST['password'];
 $pass_len= strlen($pass);    // count the string length
 $email  =  $_POST['email'];
 $phone  =  $_POST['phone'];

 if(empty($user))
 {
    $msg = "Please enter User Name !";	
 }  
 else if(empty($pass))
 {
    $msg = "Please enter Password !";	
 }  
 else if($pass_len<=6)
 {
    $msg = "Password should be more than 6 charecter !";	
 }  
 
 else if(empty($email))          
 {
    $msg = "Please enter Email !";	
 }  
 else if(!filter_var($email,FILTER_VALIDATE_EMAIL))
 {
      $msg = "Please enter valid Email !";
  }
 else if(empty($phone))
 {
    $msg = "Please enter Phone !";	
 } 
 
 else 
 {
	if(mysql_query("insert into sign_up (user,password,email,phone) values(' $user','$pass','$email','$phone ')"))
 {

        $msg1="Successfully data inserted in database, Thank you!";	 
	 
 } 
	 
  } 
}




*/

?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<form method="post">

<p>User Name:<br /> <input type="text" name="username" /></p>
<p>Password :<br /><input type="text" name="password" /> Password should be more than 6 charecter.</p>
<p>Email:<br /> <input type="text" name="email" /></p>
<p>Phone: <br /><input type="text" name="phone" /></p>
<p><input type="submit" name="submit" value="Sign Up" /></p>

<p style="color:#F00">
<?php 
   if(isset($msg))
   {
	    echo $msg;
    }
?>

</p>
<p style="color: #060">
<?php 
   if(isset($msg1))
   {
	    echo $msg1;
    }
?>

</p>


</form>


</body>
</html>