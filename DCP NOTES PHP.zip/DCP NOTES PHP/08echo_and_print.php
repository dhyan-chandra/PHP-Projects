<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<?php 

/*   


______________________________________________________________________________________________________________________________                        
						                     Difference between echo and print
_______________________________________________________________________________________________________________________________



        1.     echo and print are the same. They are both used to output data to the screen.
		2.     echo has no return value while print has a return value 
		3.     echo can take multiple parameters while print can take one argument.
		4.     echo is marginally faster than print.
		
		
______________________________________________________________________________________________________________________________                        
						                                echo 
_______________________________________________________________________________________________________________________________

          1.    The echo statement can be used with or without parentheses: echo or echo().


______________________________________________________________________________________________________________________________                        
						                                print
_______________________________________________________________________________________________________________________________


          1.     The print statement can be used with or without parentheses: print or print().

*/

?>


<?php

/*

//  echo Statement Program--1

echo "<h2>PHP is Open Source!</h2>";
echo "Hello Loosed Lang!<br>";
echo "Facebook like  PHP!<br>";
echo "This ", "string ", "was ", "made ", "with multiple parameters.";

*/

?>

<?php

/*

// echo Statement Program--2


   $txt1 = "Navodaya";
   $txt2 = "Skill Development Institute";
   $x = 2000;
   $y = 17;

   echo "<h2>$txt1</h2>";
   echo "Study PHP at <i>$txt2</i>  from ";
   echo $x + $y;

*/

?>



<?php
/*

// print Statement Program--1

   print "<h2>Navodaya</h2>";
   print "Skill Development Institute <br>";
   print ("I'm about to learn PHP!");


*/
?> 


</body>
</html>
