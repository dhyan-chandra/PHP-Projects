<?php

/*
______________________________________________________________________________________________________________________________                        
                                       Get Form
									   
									   
									   
									   
	Get request is the default form request. 
	The data passed through get request is visible on the URL browser so it is not secured.
	
	GET should NEVER be used for sending passwords or other sensitive information!
	______________________________________________________________________________________________________________________________


                    
						 
*/


?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>


<!--


<form action=" 18welcome_get.php " method = "get" >

Name: <input type = "text" name = "name"> <br>

E-mail: <input type = "text" name= "email" > <br>

<input type = "submit" name="Submit" value = "Submit" >

</form>


-->



<!--



<form action="18welcome_get.php" method="get">

<table align="center">

     <tr>
         <td>Name</td>
         <td><input type = "text" name = "name"> </td>
     
     </tr>
     
     
     <tr>
         <td>Email</td>
         <td><input type = "text" name= "email" > </td>
     
     </tr>
     
     
     <tr>
         
         <td colspan="2" align="center"><input type = "submit" name="Submit" value = "Submit" > </td>
     
     </tr>



</table>



</form>



-->

</body>
</html>
