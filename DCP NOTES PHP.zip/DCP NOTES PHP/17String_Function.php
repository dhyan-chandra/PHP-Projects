<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php

/*
______________________________________________________________________________________________________________________________                        
                                       String Function					   
	______________________________________________________________________________________________________________________________


                    
						 
*/


?>

<?php

/*
______________________________________________________________________________________________________________________________                        
                                       chunk_split()	
									   
									   
						Splits a string into a series of smaller parts				   
	______________________________________________________________________________________________________________________________
						 
*/

?>



<?php

/*

$str = " Hello world! ";

echo chunk_split( $str , 1 , "." );

*/
?> 
 



<?php

/*
______________________________________________________________________________________________________________________________                        
                                     explode()	
									 
									 
						Breaks a string into an array			   
	______________________________________________________________________________________________________________________________
						 
*/

?>


<?php

/*

$str = "Hello world. It's a beautiful day.";
print_r (explode(" ",$str));



*/

?> 


<?php

/*
______________________________________________________________________________________________________________________________                        
                                    implode()
									
									
									
					Returns a string from the elements of an array		   
	______________________________________________________________________________________________________________________________
						 
*/

?>



<?php


/*
$arr = array('Hello','World!','Beautiful','Day!');
echo implode(" ",$arr);

*/
?>




<?php

/*


$arr = array('Hello','World!','Beautiful','Day!');
echo implode(" ",$arr)."<br>";
echo implode("+",$arr)."<br>";
echo implode("-",$arr)."<br>"; 
echo implode("X",$arr);

*/

?>



<?php

/*
______________________________________________________________________________________________________________________________                        
                                    str_repeat()	
									
									
						Repeats a string a specified number of times   
	______________________________________________________________________________________________________________________________
						 
*/

?>




<?php

/*

print_r(str_split("Navodayaaaaa",3));


*/
?>




<?php

/*
______________________________________________________________________________________________________________________________                        
                                   str_replace()	
								   
								   
					Replaces some characters in a string 
					
					
					
					
					Syntax---->
                                      
									  str_replace(find,replace,string,count }
	______________________________________________________________________________________________________________________________
						 
*/

?>




<?php

/*
$arr = array("blue","red","green","yellow");

print_r(str_replace("red","pink",$arr,$i));

echo "<br>" . "Replacements: $i";

*/
?>




<?php

/*

$find = array("Hello","world");
$replace = array("B");
$arr = array("Hello","world","!");
print_r(str_replace($find,$replace,$arr));

*/

?>




<?php

/*
______________________________________________________________________________________________________________________________                        
                                 strrev()	
								 
								 
						    Reverses a string                 ______________________________________________________________________________________________________________________________
						 
*/

?>


<?php
/*

echo strrev("Hello World!");

*/

?>



<?php

/*
______________________________________________________________________________________________________________________________                        
                              	
								trim()	
								
								
				Removes whitespace or other charecter from both sides of a string                ______________________________________________________________________________________________________________________________
						 
*/

?>


<?php  

/*
$string_name="  Welcome to w3resource.com";  
$new_string=trim($string_name,"\t");  
echo $new_string;  
//var_dump($new_string);  

*/

?>  


<?php

/*

$string_name='  Welcome to Navodaya  ';  
$new_string=trim($string_name);  
echo $new_string;  
  

*/

?>



<?php  
/*

$var_name1=678;  
$var_name2="a678";  
$var_name3="678";  
$var_name4="W3resource.com";  
$var_name5=698.99;  
$var_name6=+125689.66;            
echo var_dump($var_name1)."<br>";  
echo var_dump($var_name2)."<br>";  
echo var_dump($var_name3)."<br>";  
echo var_dump($var_name4)."<br>";  
echo var_dump($var_name5)."<br>";  
echo var_dump($var_name6)."<br>";  

*/

?> 


</body>
</html>
