<?php 

/*  


_______________________________________________________________________________________________________________________________                        
						                             VARIABLE
_______________________________________________________________________________________________________________________________
	
             
			  Variables are "containers" for storing information.

_______________________________________________________________________________________________________________________________                        
						                     Rules for PHP variables
_______________________________________________________________________________________________________________________________
	      

         1.       A variable starts with the $ sign, followed by the name of the variable
		 2.       A variable name must start with a letter or the underscore character
		 3.       A variable name cannot start with a number
		 4.       A variable name can only contain alpha-numeric characters and underscores (A-z, 0-9, and _ )
		 5.       Variable names are case-sensitive ($age and $AGE are two different variables)
		 6.       PHP variable names are case-sensitive!
		 7.       Variables can be declared anywhere in the script.
		
_______________________________________________________________________________________________________________________________                        
						                       Escape-sequence replacements 
_______________________________________________________________________________________________________________________________
			                  
							
		1.  	\n is replaced by the newline character
		
		2.      \r is replaced by the carriage-return character
		
		3.      \t is replaced by the tab character
		
		4.      \$ is replaced by the dollar sign itself ($)
		
		5.      \" is replaced by a single double-quote (")
		
		6.      \\ is replaced by a single backslash (\)
       
	   
_______________________________________________________________________________________________________________________________                        
						                        Variable Naming 
_______________________________________________________________________________________________________________________________
			                 
		  
		  
        Rules for naming a variable is −---->
		

        1.       Variable names must begin with a letter or underscore character.

        2.       A variable name can consist of numbers, letters, underscores but you cannot use characters 
		          like + , - , % , ( , ) . & , etc

        3.       There is no size limit for variables.


_______________________________________________________________________________________________________________________________                        
						                   PHP is a Loosely Typed Language
_______________________________________________________________________________________________________________________________
			                 
	

                  1.        we did not have to tell PHP which data type the variable is.
				  2.        PHP automatically converts the variable to the correct data type, depending on its value.
				  3.        In other languages such as C, C++, and Java, the programmer must declare the name and type of the variable before using it.





*/


?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> Variable</title>
</head>

<body>

     <?php
           
		 /*  
		   
		   $txt = "Navodaya Skill Development institute.";
           echo "I love $txt!";
     
	     */
	 
	 ?>

    
	<?php
	     
		 /*
		 
        $txt = "Navodaya Skill Development institute. ";
        echo "I love " . $txt . "!";
     
	     */
	 
	 ?>
     
     
     <?php
          
		   /*
		   
		   // Addition of two numbers
		   
		   $x = 5;
           $y = 4;
           echo "Addition of two Number is ".($x + $y);
		   //echo "Addition of two Number is ($x + $y)";
      
	      */
	  
	  ?>
	
	
	
	<?php
	     
		 
		
        
		
		/*
		
		 $many = 2.2888800;
         $many_2 = 2.2111200;
        
		 $few = $many + $many_2;
   
         print("$many + $many_2 = $few   <br>");
    
	    */
	    
	
	
	?>
    
    
    
    
    <?php  
	
	   		   
		  
         /*
		  
		  
		  $variable = "name";
          $literally = 'My $variable will not print!';
   
          print($literally);
          print "<br>";
   
          $literally = "My $variable will print!";
          print($literally);
	     
		 */
	
	
	?>

</body>
</html>
