<?php 

/*                                     
   _______________________________________________________________________________________________________________________________                        
						                       PHP Introduction
_______________________________________________________________________________________________________________________________


        1.   PHP is a recursive acronym for "PHP: Hypertext Preprocessor".
		2.   Rasmus Lerdorf ---- 1994.
		3.   PHP is a server side scripting language that is embedded in HTML.
		4.   It is integrated with a number of popular databases, including MySQL, PostgreSQL, Oracle, Sybase, Informix, and Microsoft SQL Server.
		


_______________________________________________________________________________________________________________________________                        
						                         Common uses of PHP  
_______________________________________________________________________________________________________________________________
	
		   

         1.  PHP performs system functions, i.e. from files on a system it can create, open, read, write, and close them.

         2.  PHP can handle forms, i.e. gather data from files, save data to a file, through email you can send data, return data to the user.

         3.  We can add, delete, modify elements within database through PHP.
		 4.  Access cookies variables and set cookies.
		 5.  Using PHP, you can restrict users to access some pages of your website.
		 6.  It can encrypt data. 




_______________________________________________________________________________________________________________________________                        
						                         Characteristics of PHP
_______________________________________________________________________________________________________________________________
	
		   
         1. Simplicity
		 2. Efficiency
		 3. Security
		 4. Flexibility
		 

_______________________________________________________________________________________________________________________________                        
						                         Syntax of PHP
_______________________________________________________________________________________________________________________________
			 
   <?php
     
	    // PHP code 

   ?>
	
	
	
		 

*/


?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Hello World</title>
</head>

<body>

<?php
    echo "Hello, World!";
?>

</body>
</html>
