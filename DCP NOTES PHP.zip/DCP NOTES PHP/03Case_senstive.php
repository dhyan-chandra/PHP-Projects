<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Hello World</title>
</head>

<body>

<?php 

/*

_______________________________________________________________________________________________________________________________                        
						                          php is case senstive Language  
_______________________________________________________________________________________________________________________________
	
		
          1.    In PHP, all keywords (e.g. if, else, while, echo, etc.), classes, functions, and user-defined functions are NOT case-sensitive.
		  
		  2.     All variable names are case-sensitive.
		
		
*/

?>

<?php

/*
	
		 $capital = 67;
        
		 print("Variable capital is $capital <br>");
         print("Variable CaPiTaL is $CaPiTaL <br>");        // check variable case senstive

*/


 ?>
 
 
 
 
 <?php 
 
 /*
 
$color = "red";
echo "My toy is " . $color . "<br>";
echo "My house is " . $COLOR . "<br>";
echo "My car is " . $coLOR . "<br>";

*/
?>

 
 
<?php 
 
 
 /*
 
     ECHO "Hello World!<br>";
     echo "Hello World!<br>";
     EcHo "Hello World!<br>";

*/

?>
 
      
</body>
</html>
