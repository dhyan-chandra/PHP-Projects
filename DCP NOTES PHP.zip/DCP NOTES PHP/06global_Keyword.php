<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<?php 

/*

_______________________________________________________________________________________________________________________________                        
						                      global Keyword
_______________________________________________________________________________________________________________________________


        1.      It is used to access a global variable from within a function.
		2.      global keyword is used  before the variables (inside the function)


*/

?>


<?php
    
	
	$x = 7;
    $y = 20;

    function myTest() 
	{
       global $x, $y;        // global keyword
       $y = $x + $y;
    } 

     myTest();  
     echo 'Value of $y is '.$y; 
   
?>



</body>
</html>
