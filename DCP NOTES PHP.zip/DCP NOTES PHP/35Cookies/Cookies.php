
<?php
   setcookie("name", "Amit Chauhan", time()+3600, "/","", 0);
   setcookie("age", "30", time()+3600, "/", "",  0);
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>

<?php

/*

-------------------------------------------------------------------------------------------
                                                      Cookies


                              Cookies are text files stored on the client computer.


      three steps involved in identifying returning users -


    1.    Server script sends a set of cookies to the browser.
	2.     Browser stores this information on local machine for future use.
	3.    When next time browser sends any request to web server then it sends those cookies information to the          server and server uses that information to identify the user.
	
	
	
	                                        Setting Cookies with PHP
											
			SYNTAX---->
											
	     setcookie(name, value, expire, path, domain, security);
		 
		 
		 
		 
		 
		 Name -  This sets the name of the cookie
		 Value - This sets the value that you  want to store.
		 Expiry- Set the Expiry Time after cookie set. if you not set automatically expire when the Web Browser                 is closed.
		 
		 Path -  This specifies the directories for which the cookie is valid.
		 Domain - This can be used to specify the domain name in very large domains and must contain at least                   two periods to be valid. All cookies are only valid for the host and domain which created                   them.
		 
		 Security - This can be set to 1 to specify that the cookie should only be sent by secure transmission                   using HTTP otherwise set to 0 which mean cookie can be sent by regular HTTP.
		 
		 
		 
		 
		 NOTE--->
		 
		 
		 For accessing to the  set cookie in the environmental variables $_COOKIE or $HTTP_COOKIE_VARS[] which         holds all cookie names and values. 
		 
-------------------------------------------------------------------------------------------

*/



  

?>



<?php 
    echo " Cookies is Successfully Set . "
?>



</body>
</html>
