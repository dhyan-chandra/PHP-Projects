<?php 

include_once('Connection.php');


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
/*
----------------------------------------------------------------------------------------------------------------------------
                                       Data selected by perticular name---
----------------------------------------------------------------------------------------------------------------------------
*/
 ?>
 

<?php 
/*


$query = mysql_query("select name,email from stu_record");
while ($result=mysql_fetch_array($query))
{
   echo $result['name'] ." ". $result['email'] . "<br>";	
}


*/

?>

<?php
/*
----------------------------------------------------------------------------------------------------------------------------
                                       order by claus (asc/desc)
									   
									   
								 LIMIT decide the number of rows you want to print
									   
----------------------------------------------------------------------------------------------------------------------------
*/
 ?>
 
 
 
 <?php 

/*

$query = mysql_query("select * from stu_record order by id desc LIMIT 5");
while ($result=mysql_fetch_array($query))
{
   echo $result['id'] ." ". $result['name'] . "<br>";	
}


*/

?>



</body>
</html>