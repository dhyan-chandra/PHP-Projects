<?php 

include_once('Connection.php');


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php 


$query = mysql_query("select * from stu_record");
while ($result=mysql_fetch_array($query))
{
   echo $result['name'] ." ". $result['email'] . " ".$result['address'] . "<br>";	
}

?>

</body>
</html>